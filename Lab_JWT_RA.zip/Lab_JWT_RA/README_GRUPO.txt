LABORATÓRIO JWT — AULA 15

1. IDENTIFICAÇÃO
Turma: ______________________________
Nome completo: ______________________________ RA: ______________
Nome completo: ______________________________ RA: ______________
Nome completo: ______________________________ RA: ______________
Nome completo: ______________________________ RA: ______________
Apenas um integrante deve enviar o trabalho.

2. EXECUÇÃO
Extraia o ZIP antes de executar. Abra a pasta Lab_JWT_RA no VS Code.
Sirva a pasta com o Live Server, caso já esteja instalado, e abra index.html.
Alternativa, se Python estiver instalado: abra um terminal nessa pasta,
execute python -m http.server 5500 e acesse http://localhost:5500.
Esse comando apenas serve arquivos estáticos: não há API nem autenticação
no servidor. A aplicação é inteiramente HTML, CSS e JavaScript.
Não abra por file://: o comportamento do localStorage entre arquivos locais
pode variar. Mantenha a mesma origem (protocolo, domínio e porta).
Não é necessário npm, framework, banco de dados ou instalação de dependências
para a aplicação. Use um navegador moderno com JavaScript habilitado.

3. FUNCIONALIDADES E ARQUIVOS
index.html: formulário com labels, mensagens acessíveis e campos obrigatórios.
login.js: valida presença dos campos, impede submit padrão, grava exatamente
o JWT do enunciado na chave token e navega para area.html.
area.html: conteúdo oculto inicialmente, acesso negado, boas-vindas, claims,
estrutura colorida do token, instruções de inspeção e botão Sair.
area.js: recupera token, verifica estrutura, decodifica Base64URL/UTF-8/JSON,
trata erros, usa textContent, copia token e remove token no logout.
style.css: layout responsivo, contraste, foco de teclado e estados visuais.
evidencias/: capturas disponíveis e roteiro das capturas manuais.

Qualquer e-mail e senha fictícios não vazios iniciam a simulação. O e-mail
não altera o nome: o nome vem do token e será sempre Eng. Computação.
Não salvamos e-mail ou senha. O token original expirado é mantido conforme
a atividade. A expiração é exibida, mas não impede a simulação.

4. RESPOSTAS ÀS QUESTÕES OBRIGATÓRIAS

QUESTÃO 1 — Quais são as três partes e suas funções?
Header: metadados, como alg (HS256) e typ (JWT).
Payload: claims, como id, name, role, iat e exp.
Signature: valor criptográfico que permite verificar integridade e origem
com a chave apropriada. As partes são separadas por pontos.
Neste exemplo HS256 usa HMAC-SHA256 com segredo compartilhado: é um código
de autenticação de mensagem, não uma assinatura assimétrica.

QUESTÃO 2 — Por que o Payload pode ser visto sem a chave?
Porque está codificado em Base64URL, que é uma representação reversível,
e não criptografado. Qualquer pessoa com o token pode decodificá-lo.
A chave é necessária para conferir/produzir o HMAC, não para ler as claims.

QUESTÃO 3 — Diferença entre codificar, criptografar e assinar?
Codificar transforma a representação dos dados, sem garantir segredo.
Criptografar protege a confidencialidade; a leitura requer a chave adequada.
Assinar protege integridade e permite verificar autoria/origem sob as
condições do algoritmo e das chaves, mas não oculta o conteúdo.
Em HS256, quem conhece o segredo compartilhado pode produzir o HMAC;
portanto ele não fornece a mesma atribuição individual de uma assinatura
assimétrica com chave privada.

QUESTÃO 4 — O que ocorre se alterar o Payload sem nova assinatura?
O conteúdo assinado muda. Ao verificar com a chave correta, o HMAC calculado
não corresponde à assinatura original e a verificação falha. É preciso
manter a terceira parte original no teste: algumas ferramentas recalculam
a assinatura automaticamente ao editar o JSON quando a chave está presente.

QUESTÃO 5 — Token existente versus autenticidade?
Encontrar a chave token apenas comprova que existe um valor no armazenamento.
O próprio usuário ou um script pode alterá-lo. Decodificar também não valida
a autenticidade. A validação real deve ocorrer em uma parte confiável do
sistema, verificando assinatura com algoritmo permitido/chave confiável,
expiração e outras claims aplicáveis (como emissor e destinatário), além
de aplicar autorização para cada recurso.

QUESTÃO 6 — Finalidade de exp?
exp define o instante de expiração em segundos desde a época Unix.
Quando o instante atual alcança ou ultrapassa exp, o token deve ser
rejeitado em autenticação real, ressalvada uma eventual tolerância pequena
e controlada de relógio. Expiração não apaga o token nem impede decodificação
e não torna matematicamente incorreta sua assinatura. O exemplo expirado
serve apenas para o laboratório.

5. TESTES
Os testes de lógica confirmaram a validação dos campos, o armazenamento do
token original, a leitura do nome com acentos, o bloqueio de tokens ausentes
ou malformados e a remoção do token no logout. A assinatura foi conferida
com HMAC-SHA256: a chave correta confere; chave incorreta e alteração do
Payload invalidam a verificação. Os detalhes estão em TESTES_EXECUTADOS.txt.

Para preparar o teste 12 sem deixar a ferramenta reassinar o token, execute
no Console da aplicação APÓS fazer login:
const partes = localStorage.getItem('token').split('.');
const novoPayload = {id: 123, name: 'Alterado', role: 'JWT', iat: 1759981317, exp: 1759984917};
partes[1] = btoa(JSON.stringify(novoPayload)).replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, '');
console.log(partes.join('.'));
Copie o resultado para o verificador, mantendo a assinatura (terceira parte)
original. Este exemplo usa texto ASCII. Para texto com acentos, é necessário
codificar UTF-8 antes de usar btoa.

6. LIMITAÇÕES
Esta aplicação não oferece controle de acesso real. O código e o armazenamento
podem ser alterados pelo usuário. Não há conferência de credenciais, assinatura
ou expiração para autorizar acesso. Não há recursos privados em servidor.
JWT não é senha. Base64URL não é criptografia. Não inclua informações sensíveis
no Payload. localStorage é acessível ao JavaScript da origem; uma vulnerabilidade
XSS pode expor seus tokens. A escolha de armazenamento em sistemas reais exige
análise de segurança. O segredo my-secret-key é público e exclusivo do exemplo.
Usamos textContent para não interpretar as claims como HTML.

7. ARQUIVOS DA ENTREGA
index.html, area.html, style.css, login.js, area.js, README_GRUPO.txt,
TESTES_EXECUTADOS.txt e pasta evidencias.
